Note of the author
NOTE: This font for PERSONAL USE ONLY!

Buy commercial/corporate/extended/webfont license
Email me :mmfarhansr@gmail.com

BUY LICENCE STANDARD COMMERCIAL USE
https://www.creativefabrica.com/product/malstyoor/ref/235713/

Please visit our store for more premium fonts :
https://www.creativefabrica.com/designer/abascreative/ref/235713/

Any donation are very appreciated :
https://www.paypal.me/farhanramadhika

And follow our instagram for update :
https://www.instagram.com/abascreative/

Thank you.